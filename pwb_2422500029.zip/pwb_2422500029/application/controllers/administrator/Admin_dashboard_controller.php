<?php
defined('BASEPATH') or exit ('No direct script access allowed');

class Admin_dashboard_controller extends CI_Controller {

    public function __construct() {
        parent::__construct();
        is_admin_logged_in();
    }

    public function index() {
        $data['title'] = 'Lyn Pet Shop';
        $this->load->view('administrator/templates/header', $data);
        $this->load->view('administrator/templates/sidebar');
        $this->load->view('administrator/dashboard');
        $this->load->view('administrator/templates/footer');
    }
}
